def read_file(filename):
    with open(filename) as f:
        f.readline()
        data = list()
        for line in f:
            data.append(tuple(line.strip().split(",")))
    return data

def combine():
    file_list = [
        "rainfall-monthly-highest-daily-total.csv",
        "rainfall-monthly-number-of-rain-days.csv",
        "rainfall-monthly-total.csv",
        "relative-humidity-monthly-mean.csv",
        "surface-air-temperature-monthly-mean.csv"
    ]
    raw_list = list()
    for file in file_list:
        raw_list.append(read_file(file))
    combined_list = list()
    for cnt in range(len(raw_list[0])):
        combined_data = (
            raw_list[0][cnt][0],
            raw_list[0][cnt][1],
            raw_list[1][cnt][1],
            raw_list[2][cnt][1],
            raw_list[3][cnt][1],
            raw_list[4][cnt][1],
        )
        combined_list.append(combined_data)
    return combined_list

def write(data):
    with open("./combined_data.csv", "w") as f:
        for row in data:
            s = ",".join(row)
            s = s + "\n"
            f.write(s)

data = combine()
write(data)