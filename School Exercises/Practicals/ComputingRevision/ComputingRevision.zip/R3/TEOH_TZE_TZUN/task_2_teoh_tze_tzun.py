def read_file(filename):
    with open(filename) as f:
        data = list()
        for line in f:
            data.append(tuple(line.strip().split(",")))
    return data


def analyse(data):
    max_data = {
        "daily": None,
        "day": None,
        "month": None,
        "humidity": None,
        "air_temp": None
    }
    keys = list(max_data.keys())
    current_year = None
    for row in data:
        this_year, month = tuple(row[0].split("-"))
        if current_year is None:
            current_year = this_year
            for i, key in enumerate(keys):
                max_data[key] = (month, float(row[i+1]))
        elif current_year == this_year:
            for i, key in enumerate(keys):
                if max_data[key][1] < float(row[i+1]):
                    max_data[key] = (month, float(row[i+1]))
        else:
            print(f"For {current_year}:")
            print(f"Highest total rainfall for each year: {max_data['daily'][1]}, in {max_data['daily'][0]}")
            print(f"Highest number of rain days for each year: {max_data['day'][1]}, in {max_data['day'][0]}")
            print(f"Highest daily total rainfall for each year: {max_data['month'][1]}, in {max_data['month'][0]}")
            print(f"Highest relative humidity for each year: {max_data['humidity'][1]}, in {max_data['humidity'][0]}")
            print(f"Highest mean surface air temperature for each year: {max_data['air_temp'][1]}, in {max_data['air_temp'][0]}")
            current_year = this_year
            for i, key in enumerate(keys):
                max_data[key] = (month, float(row[i+1]))


data = read_file("./R3/TEOH_TZE_TZUN/combined_data.csv")
analyse(data)