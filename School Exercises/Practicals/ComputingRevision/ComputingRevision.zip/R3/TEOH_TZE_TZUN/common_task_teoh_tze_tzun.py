def read_file(filename):
    with open(filename) as f:
        headers_list = f.readline().strip().split(",")
        data = list()
        for line in f:
            data.append(tuple(line.strip().split(",")))
    return data


         