def read_file(path: str, ignore_header=True):
    '''
    Reads each row of a specified csv into a dictionary with the column headers as keys
    Returns the list of dictionaries representing each row of values.
    '''
    with open(path,"r") as f:
        from csv import DictReader
        return list(DictReader(f))