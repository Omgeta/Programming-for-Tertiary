from common_task_hu_man_keat import read_file

# Task 1.1
FILE_LIST = ["./rainfall-monthly-highest-daily-total.csv",
            "./rainfall-monthly-number-of-rain-days.csv",
            "./rainfall-monthly-total.csv",
            "./relative-humidity-monthly-mean.csv",
            "./surface-air-temperature-monthly-mean.csv"]


def combine():
    '''
    Combines the data from each of the files by combining each individual dictionary representing the same year-month into the same dictionary. Relies on the dict::update() method.

    Returns a list of dictionaries representing the combined data.
    '''
    # raw_combined is a list containing a list of dictionaries fetched from each file
    raw_combined = []
    for path in FILE_LIST:
        raw_combined.append(read_file(path))

    combined_data = []
    # max_index is a helper variable that lets us know when to stop iterating through our list, that is, we stop when we reach the end of the dictionaries. This assumes that each dictionary has the same length, which is a dangerous assumption in many other cases!

    max_index = len(raw_combined[0])

    for i in range(max_index):
        row = dict()
        for d in raw_combined:
            row.update(d[i])
        combined_data.append(row)
    return combined_data


def write(path: str):
    with open(path, "w", newline='') as f:
        from csv import DictWriter
        final_data = combine()
        headers = final_data[0].keys()
        writer = DictWriter(f, headers)
        
        writer.writeheader()
        writer.writerows(final_data)


write("R1/HU_MAN_KEAT/combined_data_hu_man_keat.csv")

# Task 1.2
CRITERIA = {"max_rainfall": 0,
                "rainy": 1,
                "total_rainfall": 2,
                "mean_rh": 3,
                "mean_temp": 4}

def highest_per_year(criteria: str):
    if criteria not in CRITERIA:
        return -1
    
    print(f'============================{criteria}============================')
    criteria_index = CRITERIA[criteria]
    with open("R1/HU_MAN_KEAT/combined_data_hu_man_keat.csv", "r") as f:
        from csv import reader
        read = reader(f)

        curr_year = None
        min_month, max_month = None, None
        year_min, year_max = 0, 0
        read_header = False
        for row in read:
            if not read_header:
                read_header = True
                continue

            month,max_rainfall,rainy,total_rainfall,mean_rh,mean_temp = row
            row_data = (float(max_rainfall), int(rainy), float(total_rainfall), float(mean_rh), float(mean_temp))

            year, month = month.split("-")

            if not curr_year:
                curr_year = year
                max_month = month
                year_max = row_data[criteria_index]
            
            elif year != curr_year:
                # Case when the year changes
                print(f"{curr_year}: ")
                print(f"highest daily minimum: {year_max}, month: {max_month}")

                curr_year = year
                year_max = row_data[criteria_index]
            else:
                if row_data[criteria_index] > year_max:
                    year_max = row_data[criteria_index]
                    max_month = month

for criteria in CRITERIA:
    highest_per_year(criteria)

# Task 1.3
CRITERIA = {"max_rainfall": 0,
                "rainy": 1,
                "total_rainfall": 2,
                "mean_rh": 3,
                "mean_temp": 4}

def highest_overall(criteria: str):
    if criteria not in CRITERIA:
        return -1
    
    print(f'============================{criteria}============================')
    criteria_index = CRITERIA[criteria]
    with open("R1/HU_MAN_KEAT/combined_data_hu_man_keat.csv", "r") as f:
        from csv import reader
        read = reader(f)

        max_year, highest_value = None, 0
        read_header = False
        for row in read:
            if not read_header:
                read_header = True
                continue

            month,max_rainfall,rainy,total_rainfall,mean_rh,mean_temp = row
            row_data = (float(max_rainfall), int(rainy), float(total_rainfall), float(mean_rh), float(mean_temp))

            year, _ = month.split("-")

            if not max_year:
                max_year = year
                highest_value = row_data[criteria_index]
            
            else: 
                if row_data[criteria_index] > highest_value:
                    max_year = year
                    highest_value = row_data[criteria_index]
        
    return max_year, highest_value


for criteria in CRITERIA:
    max_year, _ = highest_overall(criteria)
    print(f'Year with the highest {criteria} is {max_year}')

# Task 1.4
CRITERIA = {"max_rainfall": 0,
                "rainy": 1,
                "total_rainfall": 2,
                "mean_rh": 3,
                "mean_temp": 4}
                

def range_per_year(criteria: str):
    if criteria not in CRITERIA:
        return -1
    
    print(f'============================{criteria}============================')
    criteria_index = CRITERIA[criteria]
    with open("R1/HU_MAN_KEAT/combined_data_hu_man_keat.csv", "r") as f:
        from csv import reader
        read = reader(f)

        curr_year = None
        year_min, year_max = 0, 0
        read_header = False
        for row in read:
            if not read_header:
                read_header = True
                continue

            month,max_rainfall,rainy,total_rainfall,mean_rh,mean_temp = row
            row_data = (float(max_rainfall), int(rainy), float(total_rainfall), float(mean_rh), float(mean_temp))

            year, month = month.split("-")

            if not curr_year:
                curr_year = year
                year_min, year_max = row_data[criteria_index], row_data[criteria_index]
            
            elif year != curr_year:
                # Case when the year changes
                print(f"{curr_year}: ")
                print(f"difference: {round(year_max-year_min,1)}")

                curr_year = year
                year_min, year_max = row_data[criteria_index], row_data[criteria_index]
            else:
                if row_data[criteria_index] < year_min:
                    year_min = row_data[criteria_index]
                if row_data[criteria_index] > year_max:
                    year_max = row_data[criteria_index]

for criteria in CRITERIA:
    range_per_year(criteria)
