import csv

#Task 1.1

#read files, store into nested list of dicts
filenames = ['rainfall-monthly-highest-daily-total.csv', 'rainfall-monthly-number-of-rain-days.csv', 'rainfall-monthly-total.csv', 'relative-humidity-monthly-mean.csv', 'surface-air-temperature-monthly-mean.csv']

raw = []
for file in filenames:
    with open(file, 'r') as f:
        headers = f.readline()
        for row in csv.DictReader(f):
            monthexists = False
            j = 0
            while (monthexists != True) or (j != (len(raw) - 1)):
                if raw[j]['month'] == row['month']:
                    for header in headers:
                        raw[j][header] = row[header] #add into dict
                    monthexists = True
                j += 1
            if monthexists == False:
                
                raw.append(row)
    f.close()

print(raw)

