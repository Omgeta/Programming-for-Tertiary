from common_task_zheng_nan import read_file
import csv

# pardon the terrible variable naming/function signatures and code formatting

# pls do tell me if that are any errors with the data processing. did not have a solution to check against

# Task 1.1
filenames = [
    "rainfall-monthly-highest-daily-total",
    "rainfall-monthly-number-of-rain-days",
    "rainfall-monthly-total",
    "relative-humidity-monthly-mean",
    "surface-air-temperature-monthly-mean",
]


def combine(filenames: list) -> dict:
    """Merge csv files with relation to common column 'month'"""
    data = {}
    for filename in filenames:
        file_data = read_file(filename)
        for row in file_data:
            # Since month is the essential element here, we will create records in the dictionary using it as a key
            if row["month"] not in data.keys():
                data[row["month"]] = {}
            # Populate values
            for value in row:
                # We will also dump 'month' into the value itself too for the ease of writing to the csv later
                data[row["month"]][value] = row[value]
    return data


def write(file_path: str, data: dict) -> None:
    """Dump merged contents to a csv file"""
    with open(file_path, "w+") as f:
        # Dynamically generate headers
        fieldnames = list(list(data.values())[0].keys())

        # Force month to become first field
        fieldnames.remove("month")
        fieldnames.insert(0, "month")

        # Write to CSV
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data.values())
        # write values of data, meaning the month key does not get written, only the values. CSV module will automagically correspond each row in your values to the column header, thus no further work is needed


# Run
data = combine(filenames)
write("./combined_data.csv", data)

# owo

# Task 1.2


def generate_year_data(data: dict) -> dict:
    """
    Generates a dictionary from an array of months withth
    the year as a key
    """
    year_dict = {}
    for month in data:
        year = month.split("-")[0]
        if year not in year_dict.keys():
            # init if not exist
            year_dict[year] = []
        year_dict[year] = year_dict[year] + [data[month]]
        # extend the corresponding list everytime a new month is found
    return year_dict


def year_max(year_arr: list, key: str, returnMonth=True) -> tuple:
    """
    Helper function to determine min and max for a year
    """
    # This is an attempt to implement a universal helper function for ease of access later
    _max = None
    _min = None
    min_month = None
    max_month = None
    for month in year_arr:
        parsed_month = month["month"][-2:]
        if not any((_max, _min, min_month, max_month)):
            _min, min_month = float(month[key]), parsed_month
            _max, max_month = float(month[key]), parsed_month
        if float(month[key]) > _max:
            _max, max_month = float(month[key]), parsed_month
        if float(month[key]) < _min:
            _min, min_month = float(month[key]), parsed_month

    if returnMonth:
        return (_max, max_month, _min, min_month)
    return (_max, _min)


def text_output_year(year_dict: dict) -> None:
    """
    Output data about each criterion in each year
    """
    # self explaining
    for year_no in year_dict:
        year = year_dict[year_no]
        max_daily_rf = year_max(year, key="maximum_rainfall_in_a_day")
        max_total_rf = year_max(year, key="total_rainfall")
        max_rd = year_max(year, key="no_of_rainy_days")
        max_rh = year_max(year, key="mean_rh")
        max_stemp = year_max(year, key="mean_temp")
        print(
            f"""
For {year_no}:
Highest total rainfall: {max_total_rf[0]}, in {max_total_rf[1]}
Highest daily total rainfall: {max_daily_rf[0]}, in {max_daily_rf[1]}
Highest number of rain days: {max_rd[0]}, in {max_rd[1]}
Highest relative humidity: {max_rh[0]}, in {max_rh[1]}
Highest mean surface air temperature: {max_stemp[0]}, in {max_stemp[1]}
        """
        )


# Run
text_output_year(generate_year_data(data))

# Task 1.3


def overall_max(data: dict, key=None) -> str:
    """
    Directly return year since no requirement to return
    the value itself
    """
    # do manual comparison if lambda is not allowed
    # what this line does is to basically find the maximum with relation to the criterion here. Variable "v" will be returned, which is the year which max occurs
    return max(data, key=lambda v: float(data[v][key]))[:-3]


def text_output_max_year() -> None:
    """
    Outputs maximum criterions out of all the years
    """
    # self-explanatory
    max_daily_rf = overall_max(data, key="maximum_rainfall_in_a_day")
    max_total_rf = overall_max(data, key="total_rainfall")
    max_rd = overall_max(data, key="no_of_rainy_days")
    max_rh = overall_max(data, key="mean_rh")
    max_stemp = overall_max(data, key="mean_temp")
    print(
        f"""
Overall stats:
Highest total rainfall in {max_total_rf}
Highest daily total rainfall in {max_daily_rf}
Highest number of rain days in {max_rd}
Highest relative humidity in {max_rh}
Highest mean surface air temperature in {max_stemp}
        """
    )


# Run
text_output_max_year()

# Task 1.4


def difference_output_year(year_dict: dict) -> None:
    """
    Output difference between the max and min of
    different criterias
    """
    # self-explanatory
    for year_no in year_dict:
        year = year_dict[year_no]

        # Retrieve min-max for values
        max_daily_rf, min_daily_rf = year_max(
            year, key="maximum_rainfall_in_a_day", returnMonth=False
        )
        max_total_rf, min_total_rf = year_max(
            year, key="total_rainfall", returnMonth=False
        )
        max_rd, min_rd = year_max(year, key="no_of_rainy_days", returnMonth=False)
        max_rh, min_rh = year_max(year, key="mean_rh", returnMonth=False)
        max_stemp, min_stemp = year_max(year, key="mean_temp", returnMonth=False)

        # Calculate difference
        diff_daily_rf = max_daily_rf - min_daily_rf
        diff_total_rf = max_total_rf - min_total_rf
        diff_rd = max_rd - min_rd
        diff_rh = max_rh - min_rh
        diff_stemp = max_stemp - min_stemp

        # Output
        print(
            f"""
For {year_no}:
Difference between highest and lowest total rainfall: {diff_total_rf}
Difference between highest and lowest daily total rainfall: {diff_daily_rf}
Difference between highest and lowest number of rain days: {diff_rd}
Difference between highest and lowest relative humidity: {diff_rh}
Difference between highest and lowest mean surface air temperature: {diff_stemp}
        """
        )


# Run
difference_output_year(generate_year_data(data))
