import csv

def read_file(filename):
    data = csv.DictReader(open(f"{filename}.csv", 'r'))
    return data